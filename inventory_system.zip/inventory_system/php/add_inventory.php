<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_number = $_POST['product_number'];
    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $available_stock = $_POST['available_stock'];
    $status = $_POST['status'];

    $sql = "INSERT INTO products (product_number, product_name, category, available_stock, status)
            VALUES ('$product_number', '$product_name', '$category', '$available_stock', '$status')";

    if ($conn->query($sql) === TRUE) {
        echo "Item baru berhasil disimpan";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>