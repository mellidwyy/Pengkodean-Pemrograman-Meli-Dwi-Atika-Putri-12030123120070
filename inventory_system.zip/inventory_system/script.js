$(document).ready(function() {
    // Ambil data inventaris saat halaman dimuat
    $.ajax({
        url: 'php/get_inventory.php',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
            populateTable(data);
            updateSummary(data);
        }
    });

    // Tangani penyimpanan produk baru
    $('#save-product').click(function() {
        var product = {
            product_number: $('#product-number').val(),
            product_name: $('#product-name').val(),
            category: $('#category').val(),
            available_stock: $('#available-stock').val(),
            status: $('#status').val()
        };

        $.ajax({
            url: 'php/add_inventory.php',
            type: 'POST',
            data: product,
            success: function(response) {
                alert(response);
                $('#addProductModal').modal('hide');
                // Perbarui tabel
                $.ajax({
                    url: 'php/get_inventory.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        populateTable(data);
                        updateSummary(data);
                    }
                });
            }
        });
    });

    // Fungsi untuk mengisi tabel
    function populateTable(data) {
        var tableBody = $('#inventory-table-body');
        tableBody.empty();
        $.each(data, function(index, product) {
            var row = '<tr>' +
                '<td>' + product.product_number + '</td>' +
                '<td>' + product.product_name + '</td>' +
                '<td>' + product.category + '</td>' +
                '<td>' + product.available_stock + '</td>' +
                '<td>' + product.status + '</td>' +
                '<td><button class="btn btn-sm btn-primary">Edit</button></td>' +
                '</tr>';
            tableBody.append(row);
        });
    }

    // Fungsi untuk memperbarui ringkasan
    function updateSummary(data) {
        var nonTracked = data.filter(function(product) {
            return product.category !== 'Tracked';
        }).length;
        $('#non-tracked-count').text(nonTracked);
    }
});